    <?php $__env->startSection('title',"Page personne"); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/people.css')); ?>">
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('contenu'); ?>
    
    <h1>Page de <?php echo e($personne->nom); ?></h1>
    <?php if(isset($personne)): ?>
        <div>
            <h1>Nom: <?php echo e($personne->nom); ?></h1>
            <?php if (str_starts_with($personne->photo, 'http')) {?>
                <img src="<?php echo e($personne->photo); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
            <?php } else {?>
                <img src="<?php echo e(asset('img/personnes/' . $personne->photo)); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
            <?php }?>
            <p>Date de naissance: <?php echo e($personne->dateNaissance); ?></p>
            <p>Lieu de naissance:<?php echo e($personne->LieuNaissance); ?></p>
            <p>Role principal: <?php echo e($personne->rolePrincipal); ?></p>
            <a href="<?php echo e(route('Netflix.modPersonne' , [$personne])); ?>"><button class="button">Modifier</button></a>
            <form method="post" action="<?php echo e(route('Netflix.destroyPersonne', [$personne->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="button">SUPPRIMER</button>
            </form>
        </div>
    <?php else: ?>
        <p>La personne n'existe pas</p>
    <?php endif; ?>
    <?php $__currentLoopData = $personne->films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1><?php echo e($film->titre); ?></h1>
        <?php if (str_starts_with($film->pochette, 'http')) {?>
            <img id="affiche" src="<?php echo e($film->pochette); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
        <?php } else {?>
            <img id="affiche" src="<?php echo e(asset('img/films/' . $film->pochette)); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
        <?php }?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Year 2\part 1\Web3\NETFLIX\Netflix\resources\views/Netflix/peoples.blade.php ENDPATH**/ ?>