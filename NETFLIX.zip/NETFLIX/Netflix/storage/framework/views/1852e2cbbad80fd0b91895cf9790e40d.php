    <?php $__env->startSection('title',"personnes"); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/personne.css')); ?>">
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('menu'); ?>
      <nav class="main-nav">                
        <a href="#home">Home</a>
        <a href="#Realisateur">Realisateur</a>
        <a href="#Acteur">Acteur</a>
        <a href="#Producteur">Producteur</a>
        <a href="#USA">USA</a>
      </nav>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('contenu'); ?>  
    <section class="main-container" >
      <div class="location" id="home">
          <h1 id="home">Né avant 1950</h1>
          <div class="box">
            <?php if(count($personnes)): ?>
              <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($personne->dateNaissance < '1950-01-01'): ?>
                <div style="text-align:center;">
                  <h2 id="name"><?php echo e($personne->nom); ?></h2>
                  <a href="<?php echo e(route('Netflix.peoples', [$personne])); ?>">
                    <?php if (str_starts_with($personne->photo, 'http')) {?>
                        <img src="<?php echo e($personne->photo); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                        
                    <?php } else {?>
                        <img src="<?php echo e(asset('img/personnes/' . $personne->photo)); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                    <?php }?>
                  </a>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
              <?php else: ?>
                <p>Aucune personnes</p>
            <?php endif; ?>                  
          </div>

          <h1 id="Realisateur">Réalisateur</h1>
          <div class="box">
            <?php if(count($personnes)): ?>
              <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($personne->rolePrincipal == 'Réalisateur'): ?>
                <div style="text-align:center;">
                  <h2 id="name"><?php echo e($personne->nom); ?></h2>
                  <a href="<?php echo e(route('Netflix.peoples', [$personne])); ?>">
                    <?php if (str_starts_with($personne->photo, 'http')) {?>
                        <img src="<?php echo e($personne->photo); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                        
                    <?php } else {?>
                        <img src="<?php echo e(asset('img/personnes/' . $personne->photo)); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                    <?php }?>
                  </a>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
              <?php else: ?>
                <p>Aucune personnes</p>
            <?php endif; ?>                  
          </div>

          <h1 id="Acteur">Acteur</h1>
          <div class="box">
            <?php if(count($personnes)): ?>
              <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($personne->rolePrincipal == 'Acteur'): ?>
                <div style="text-align:center;">
                  <h2 id="name"><?php echo e($personne->nom); ?></h2>
                  <a href="<?php echo e(route('Netflix.peoples', [$personne])); ?>">
                    <?php if (str_starts_with($personne->photo, 'http')) {?>
                        <img src="<?php echo e($personne->photo); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                        
                    <?php } else {?>
                        <img src="<?php echo e(asset('img/personnes/' . $personne->photo)); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                    <?php }?>
                  </a>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
              <?php else: ?>
                <p>Aucune personnes</p>
            <?php endif; ?>                  
          </div>

          <h1 id="Producteur">Producteur</h1>
          <div class="box">
            <?php if(count($personnes)): ?>
              <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($personne->rolePrincipal == 'Producteur'): ?>
                <div style="text-align:center;">
                  <h2 id="name"><?php echo e($personne->nom); ?></h2>
                  <a href="<?php echo e(route('Netflix.peoples', [$personne])); ?>">
                      <?php if (str_starts_with($personne->photo, 'http')) {?>
                          <img src="<?php echo e($personne->photo); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                          
                      <?php } else {?>
                          <img src="<?php echo e(asset('img/personnes/' . $personne->photo)); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                      <?php }?>
                  </a>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
              <?php else: ?>
                <p>Aucune personnes</p>
            <?php endif; ?>                  
          </div>

          <h1 id="USA">USA</h1>
          <div class="box">
            <?php if(count($personnes)): ?>
              <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(strpos($personne->LieuNaissance, 'USA') !== false): ?>
                <div style="text-align:center;">
                  <h2 id="name"><?php echo e($personne->nom); ?></h2>
                  <a href="<?php echo e(route('Netflix.peoples', [$personne])); ?>">
                    <?php if (str_starts_with($personne->photo, 'http')) {?>
                        <img src="<?php echo e($personne->photo); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                        
                    <?php } else {?>
                        <img src="<?php echo e(asset('img/personnes/' . $personne->photo)); ?>" alt="<?php echo e($personne->nom); ?>" title="<?php echo e($personne->nom); ?>">
                    <?php }?>
                  </a>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
              <?php else: ?>
                <p>Aucun films</p>
            <?php endif; ?>                  
          </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Year 2\part 1\Web3\NETFLIX\Netflix\resources\views/Netflix/personnes.blade.php ENDPATH**/ ?>