

    <?php $__env->startSection('title',"Page add"); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/add.css')); ?>">
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('contenu'); ?>
    <?php if(auth()->guard()->check()): ?>
    <div class="main-container">
        <a href="<?php echo e(route('Netflix.addPersonne')); ?>"><button type="button" class="button">Ajouter Personne</button></a>
        <a href="<?php echo e(route('Netflix.addFilmPersonne')); ?>"><button type="button" class="button">Ajouter Lien Personne et Film</button></a>
        <a href="<?php echo e(route('Netflix.addFilm')); ?>"><button type="button" class="button">Ajouter Film</button></a>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Year 2\part 1\Web3\NETFLIX\Netflix\resources\views/Netflix/add.blade.php ENDPATH**/ ?>