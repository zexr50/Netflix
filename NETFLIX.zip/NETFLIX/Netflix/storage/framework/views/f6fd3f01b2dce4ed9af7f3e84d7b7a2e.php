

    <?php $__env->startSection('title',"Page modifier film"); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/add.css')); ?>">
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('contenu'); ?>

    <form method="post" action="<?php echo e(route('Netflix.updatePersonne' , [$personne])); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <div class="main-container">
            <label for="nomPersonne">Nom de la personne</label>
            <input type="text" class="form-control" id="nomPersonne" placeholder="Nom de la personne" name="nom" required>

            <label for="dateNaissance">Date de naissance</label>
            <input type="date" class="form-control" id="dateNaissance" name="dateNaissance" required>

            <label for="lieuNaissance">Lieu de naissance</label>
            <input type="text" class="form-control" id="lieuNaissance" placeholder="Lieu de naissance" name="LieuNaissance" required>

            <label for="photo">Photo</label>
            <input type="text" class="form-control" id="photo" placeholder="photo de la personne" name="photo" required>

            <label for="rolePrincipal">Rôle principal</label>
            <input type="text" class="form-control" id="rolePrincipal" placeholder="Rôle principal" name="rolePrincipal" required>
        </div>

        <button type="submit" class="button">Enregistrer</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Year 2\part 1\Web3\NETFLIX\Netflix\resources\views/Netflix/modPersonne.blade.php ENDPATH**/ ?>