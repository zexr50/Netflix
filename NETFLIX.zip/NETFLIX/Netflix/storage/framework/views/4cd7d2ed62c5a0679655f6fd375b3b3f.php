

    <?php $__env->startSection('title',"Page add FilmPersonne"); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/add.css')); ?>">
    <?php echo $__env->yieldSection(); ?>
    <?php $__env->startSection('contenu'); ?>
    <form method="post" action="<?php echo e(route('Netflix.storeFilmPersonne')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="main-container">
            <label for="film_id">ID Film</label>
            <input type="text" class="form-control" id="film_id" placeholder="film_id [id]" name="film_id" required>

            <label for="personne_id">ID Personne</label>
            <input type="text" class="form-control" id="personne_id"  placeholder="personne_id [id]" name="personne_id" required>

            <label for="lieuNaissance">role</label>
            <input type="text" class="form-control" id="role" placeholder="role" name="role" required>

        </div>

        <button type="submit" class="button">Enregistrer</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Year 2\part 1\Web3\NETFLIX\Netflix\resources\views/Netflix/addFilmPersonne.blade.php ENDPATH**/ ?>