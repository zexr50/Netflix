    <?php $__env->startSection('title',"films"); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <?php echo $__env->yieldSection(); ?>

    <?php $__env->startSection('menu'); ?>
      <nav class="main-nav">                
        <a href="#home">Home</a>
        <a href="#Action">Action</a>
        <a href="#Aventure">Aventure</a>
        <a href="#Francais">Français</a>
        <a href="#Allemand">Allemand</a>
        <?php if(auth()->guard()->check()): ?>
          <a class="btn btn-default" href="<?php echo e(route('Netflix.add')); ?>">Ajouter</a> 
        <?php endif; ?>
        <a class="btn btn-default" href="<?php echo e(route('Netflix.personnes')); ?>">Regarder Personne</a>     
      </nav>
    <?php $__env->stopSection(); ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

        <script>
          alert("success");
        </script>
    </div>
    <?php endif; ?>
    <?php if(session('erreur')): ?>
    <div class="alert alert-erreur">
        <?php echo e(session('erreur')); ?>

        <script>
          alert("erreur");
        </script>
    </div>
    <?php endif; ?>

    <?php $__env->startSection('contenu'); ?>  
    <!-- MAIN CONTAINER -->
    <section class="main-container" >
      <div class="location" id="home">
          <h1 id="home">Populaire</h1>
          <div class="box">
            <?php if(count($films)): ?>
              <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($film->cote >=90): ?>
                <div style="text-align:center;">
                  <h2 id="name"><?php echo e($film->titre); ?></h2>
                  <a href="<?php echo e(route('Netflix.films', [$film])); ?>">
                    <?php if (str_starts_with($film->pochette, 'http')) {?>
                        <img id="affiche" src="<?php echo e($film->pochette); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                    <?php } else {?>
                        <img id="affiche" src="<?php echo e(asset('img/films/' . $film->pochette)); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                    <?php }?>
                  </a>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
              <?php else: ?>
                <p>Aucun films</p>
            <?php endif; ?>
          </div>
      </div>
      

      <h1 id="Action">Action</h1>
      <div class="box">
        <?php if(count($films)): ?>
          <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(strpos($film->type, 'Action') !== false): ?>
            <div style="text-align:center;">
              <h2 id="name"><?php echo e($film->titre); ?></h2>
              <a href="<?php echo e(route('Netflix.films', [$film])); ?>">
                    <?php if (str_starts_with($film->pochette, 'http')) {?>
                        <img id="affiche" src="<?php echo e($film->pochette); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                    <?php } else {?>
                        <img id="affiche" src="<?php echo e(asset('img/films/' . $film->pochette)); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                    <?php }?>
              </a>
            </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
          <?php else: ?>
            <p>Aucun films</p>
        <?php endif; ?>                  
      </div>
      
      <h1 id="Aventure">Aventure</h1>
      <div class="box">
        <?php if(count($films)): ?>
          <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(strpos($film->type, 'Aventure') !== false): ?>
            <div style="text-align:center;">
              <h2 id="name"><?php echo e($film->titre); ?></h2>
              <a href="<?php echo e(route('Netflix.films', [$film])); ?>">
                <?php if (str_starts_with($film->pochette, 'http')) {?>
                    <img id="affiche" src="<?php echo e($film->pochette); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                <?php } else {?>
                    <img id="affiche" src="<?php echo e(asset('img/films/' . $film->pochette)); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                <?php }?>
              </a>
            </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
          <?php else: ?>
            <p>Aucun films</p>
        <?php endif; ?>              
      </div>
      

      <h1 id="Francais">Français</h1>
      <div class="box">
        <?php if(count($films)): ?>
          <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(strpos($film->langues, 'Français') !== false): ?>
            <div style="text-align:center;">
              <h2 id="name"><?php echo e($film->titre); ?></h2>
              <a href="<?php echo e(route('Netflix.films', [$film])); ?>">
                <?php if (str_starts_with($film->pochette, 'http')) {?>
                    <img id="affiche" src="<?php echo e($film->pochette); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                <?php } else {?>
                    <img id="affiche" src="<?php echo e(asset('img/films/' . $film->pochette)); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                <?php }?>
              </a>
            </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
          <?php else: ?>
            <p>Aucun films</p>
        <?php endif; ?>            
      </div>

      <h1 id="Allemand">Allemand</h1>
      <div class="box">
        <?php if(count($films)): ?>
          <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(strpos($film->langues, 'Allemand') !== false): ?>
            <div style="text-align:center;">
              <h2 id="name"><?php echo e($film->titre); ?></h2>
              <a href="<?php echo e(route('Netflix.films', [$film])); ?>">
                <?php if (str_starts_with($film->pochette, 'http')) {?>
                    <img id="affiche" src="<?php echo e($film->pochette); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                <?php } else {?>
                    <img id="affiche" src="<?php echo e(asset('img/films/' . $film->pochette)); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
                <?php }?>
              </a>
            </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
          <?php else: ?>
            <p>Aucun films</p>
        <?php endif; ?>                
      </div>
      

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Year 2\part 1\Web3\NETFLIX\Netflix\resources\views/Netflix/home.blade.php ENDPATH**/ ?>