    <?php $__env->startSection('title',"Page Films"); ?>
    <?php $__env->startSection('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/films.css')); ?>">
    <?php echo $__env->yieldSection(); ?>

    <?php $__env->startSection('contenu'); ?>
    
    <h1>Page du film <?php echo e($film->titre); ?></h1>
    <?php if(isset($film)): ?>
        <div>
            <h1 id="titre"><?php echo e($film->titre); ?></h1>
            <?php if (str_starts_with($film->pochette, 'http')) {?>
                <img id="affiche" src="<?php echo e($film->pochette); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
            <?php } else {?>
                <img id="affiche" src="<?php echo e(asset('img/films/' . $film->pochette)); ?>" alt="<?php echo e($film->titre); ?>" title="<?php echo e($film->titre); ?>">
            <?php }?>
            <p id="resume">resume: <?php echo e($film->resume); ?></p>
            <p id="duree">durée: <?php echo e($film->durée); ?></p>
            <p>année: <?php echo e($film->année); ?></p>
            <iframe width="420" height="315"src="<?php echo e($film->lienVideo); ?>"></iframe>
            <p>type: <?php echo e($film->type); ?></p>
            <p>brand: <?php echo e($film->brand); ?></p>
            <p>cote: <?php echo e($film->cote); ?></p>
            <p>rating: <?php echo e($film->rating); ?></p>
            <p>langues: <?php echo e($film->langues); ?></p>
            <p>sous titres: <?php echo e($film->sousTitres); ?></p>
            <a href="<?php echo e(route('Netflix.modFilm' , [$film])); ?>"><button class="button">Modifier</button></a>

            <form method="post" action="<?php echo e(route('Netflix.destroyFilm', [$film->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="button">SUPPRIMER</button>
            </form>

        </div>
    <?php else: ?>
        <p>Le film n'existe pas</p>
    <?php endif; ?>
    
    <h2>REALISATEUR</h2>
    <h3 id="name"><?php echo e($film->realisateur->nom); ?></h3>
    <a href="<?php echo e(route('Netflix.peoples', [$film->realisateur])); ?>">
        <?php if (str_starts_with($film->realisateur->photo, 'http')) {?>
            <img src="<?php echo e($film->realisateur->photo); ?>" alt="<?php echo e($film->realisateur->nom); ?>" title="<?php echo e($film->realisateur->nom); ?>">
        <?php } else {?>
            <img src="<?php echo e(asset('img/personnes/' . $film->realisateur->photo)); ?>" alt="<?php echo e($film->realisateur->nom); ?>" title="<?php echo e($film->realisateur->nom); ?>">
        <?php }?>
    </a>

    <h2>PRODUCTEUR</h2>
    <h3 id="name"><?php echo e($film->producteur->nom); ?></h3>
    <a href="<?php echo e(route('Netflix.peoples', [$film->producteur])); ?>">
        <?php if (str_starts_with($film->producteur->photo, 'http')) {?>
            <img src="<?php echo e($film->producteur->photo); ?>" alt="<?php echo e($film->producteur->nom); ?>" title="<?php echo e($film->producteur->nom); ?>">
        <?php } else {?>
            <img src="<?php echo e(asset('img/personnes/' . $film->producteur->photo)); ?>" alt="<?php echo e($film->producteur->nom); ?>" title="<?php echo e($film->producteur->nom); ?>">
        <?php }?>
    </a>

    <h2>ACTEURS</h2>
    <?php if(isset($film->personne[0]->photo)): ?>
    <?php $__currentLoopData = $film->personne; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($photo->id == $film->realisateur->id || $photo->id == $film->producteur->id): ?>
            <?php continue; ?>
        <?php endif; ?>
        <h3 id="name"><?php echo e($photo->nom); ?></h3>
        <a href="<?php echo e(route('Netflix.peoples', [$photo])); ?>">
            <?php if (str_starts_with($photo->photo, 'http')) {?>
                <img src="<?php echo e($photo->photo); ?>" alt="<?php echo e($photo->nom); ?>" title="<?php echo e($photo->nom); ?>">
            <?php } else {?>
                <img src="<?php echo e(asset('img/personnes/' . $photo->photo)); ?>" alt="<?php echo e($photo->nom); ?>" title="<?php echo e($photo->nom); ?>">
            <?php }?>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <h1>No photos available.</h1>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Year 2\part 1\Web3\NETFLIX\Netflix\resources\views/Netflix/films.blade.php ENDPATH**/ ?>