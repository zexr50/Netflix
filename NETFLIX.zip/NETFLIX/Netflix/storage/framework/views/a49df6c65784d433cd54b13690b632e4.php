    

    <?php $__env->startSection('title',"Page Films"); ?>

    <?php $__env->startSection('contenu'); ?>
    <h1>CONTENU DU SITE PAGE FILM</h1>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Year 2\part 1\Web3\NETFLIX\HelloLaravelCode\Netflix\resources\views/Netflix/films.blade.php ENDPATH**/ ?>